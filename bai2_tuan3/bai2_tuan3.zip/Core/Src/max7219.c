#include "max7219.h"

void SPI1_Init(void) {
    // Bật clock GPIOA (Bit 2) và SPI1 (Bit 12)
    RCC->APB2ENR |= (1 << 2) | (1 << 12);

    // PA4 (CS): Output 50MHz Push-Pull
    GPIOA->CRL &= ~(0xF << 16);
    GPIOA->CRL |= (0x3 << 16);
    GPIOA->BSRR = (1 << 4); // PA4 High

    // PA5 (SCK) & PA7 (MOSI): AF 50MHz Push-Pull (0xB)
    GPIOA->CRL &= ~((0xF << 20) | (0xF << 28));
    GPIOA->CRL |= ((0xB << 20) | (0xB << 28));

    // SPI1: Master, Baudrate PCLK2/16, SSM=1, SSI=1, SPE=1
    SPI1->CR1 = (1 << 2) | (0x3 << 3) | (1 << 8) | (1 << 9) | (1 << 6);
}

static uint8_t SPI1_Transmit(uint8_t data) {
    while (!(SPI1->SR & (1 << 1))); // Wait TXE
    SPI1->DR = data;
    while (!(SPI1->SR & (1 << 0))); // Wait RXNE
    return SPI1->DR;
}

void MAX7219_WriteReg(uint8_t reg, uint8_t data) {
    GPIOA->BSRR = (1 << 20); // PA4 Low (BR4)
    SPI1_Transmit(reg);
    SPI1_Transmit(data);
    GPIOA->BSRR = (1 << 4);  // PA4 High (BS4)
}

void MAX7219_Clear(void) {
    for (uint8_t i = 1; i <= 8; i++) {
        MAX7219_WriteReg(i, 0x0F); // 0x0F = blank (chỉ có tác dụng ở BCD decode mode)
    }
}

void MAX7219_Init(void) {
    SPI1_Init();

    MAX7219_WriteReg(MAX7219_REG_DISPLAYTEST, 0x00);
    MAX7219_WriteReg(MAX7219_REG_SCANLIMIT,   0x07);
    MAX7219_WriteReg(MAX7219_REG_DECODEMODE,  0xFF); // BCD decode cho cả 8 digit
    MAX7219_WriteReg(MAX7219_REG_INTENSITY,   0x03);
    MAX7219_WriteReg(MAX7219_REG_SHUTDOWN,    0x01);

    MAX7219_Clear();
}

void MAX7219_DisplayDigit(uint8_t digit) {
    if (digit > 9) return;
    MAX7219_WriteReg(1, digit); // Ghi số vào DIG0 (digit ngoài cùng bên phải)
}
