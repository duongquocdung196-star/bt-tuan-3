#include "main.h"

uint32_t SystemCoreClock = 8000000;

void SystemInit(void) {
    // Khoi tao he thong mac dinh
}
