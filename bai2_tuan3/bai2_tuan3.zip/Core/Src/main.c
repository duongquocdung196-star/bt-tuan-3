#include "main.h"
#include "max7219.h"

void Delay_ms(uint32_t ms) {
    for (volatile uint32_t i = 0; i < ms * 2000; i++) {
        __asm("NOP");
    }
}

int main(void) {
    MAX7219_Init();

    uint8_t count = 0;

    while (1) {
        MAX7219_DisplayDigit(count);
        
        count++;
        if (count > 9) {
            count = 0;
        }

        Delay_ms(1000);
    }
}
